package model;

public class StudentImpl {
	void accessStudent() {
		Student s = new Student();
//		s.studentId = 1;
//		s.studentName = "Prithvi";
//		s.age = 16;
	}
}
